 

import { useState } from "react";
import { FiBell, FiHelpCircle, FiChevronDown, FiSearch, FiUser, FiHome, FiUsers, FiBriefcase, FiRepeat, FiPieChart, FiFileText, FiSettings, FiMail, FiPhone, FiShield, FiAlertTriangle, FiRotateCcw, FiMenu, FiX } from "react-icons/fi";
import { BsPersonBadge, BsFingerprint, BsBank2 } from "react-icons/bs";
import { MdOutlineVerified } from "react-icons/md";

const NAV_ITEMS = [
  { icon: <FiHome size={18} />, label: "Dashboard" },
  { icon: <FiHome size={18} />, label: "Properties" },
  { icon: <FiUsers size={18} />, label: "Investors", active: true },
  { icon: <FiBriefcase size={18} />, label: "Brokers" },
  { icon: <FiPieChart size={18} />, label: "Investments" },
  { icon: <FiRepeat size={18} />, label: "Transactions" },
  { icon: <FiPieChart size={18} />, label: "Portfolio Control" },
  { icon: <FiFileText size={18} />, label: "Documents" },
  { icon: <FiSettings size={18} />, label: "Settings" },
];

const TABS = ["Profile", "Investments", "Portfolio", "Transactions", "Documents", "Audit Logs"];

const AUDIT_ROWS = [
  { user: "Sarah Connor", initials: "SC", field: "KYC Status", old: "Pending", newVal: "Approved", time: "Dec 01, 2023 • 14:20", highlight: true },
  { user: "Michael Ross", initials: "MR", field: "Bank Account No.", old: "**** 4421", newVal: "**** 8921", time: "Nov 28, 2023 • 09:45", highlight: false },
];

function Sidebar({ open, setOpen }) {
  return (
    <>


      {open && <div className="fixed inset-0 bg-black bg-opacity-40 z-20 lg:hidden" onClick={() => setOpen(false)} />}
      <aside className={`fixed top-0 left-0 h-full w-48 bg-gray-900 z-30 flex flex-col transition-transform duration-300 ${open ? "translate-x-0" : "-translate-x-full"} lg:translate-x-0 lg:static lg:z-auto`}>
        <div className="flex items-center gap-2.5 px-4 py-4 border-b border-gray-800">
          <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center shrink-0">
            <FiHome size={16} className="text-white" />
          </div>
          <div>
            <p className="text-white text-xs font-bold leading-tight">Sovereign Admin</p>
            <p className="text-gray-400 text-[10px]">FRACTIONAL ESTATE</p>
          </div>
        </div>
        <nav className="flex-1 px-2 py-4 space-y-0.5 overflow-y-auto">
          {NAV_ITEMS.map(item => (
            <button key={item.label} className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-left transition-colors ${item.active ? "bg-emerald-600 text-white" : "text-gray-400 hover:bg-gray-800 hover:text-white"}`}>
              {item.icon}
              <span className="text-xs font-medium">{item.label}</span>
            </button>
          ))}
        </nav>
        <div className="flex items-center gap-2.5 px-4 py-4 border-t border-gray-800">
          <div className="w-8 h-8 rounded-full bg-gray-600 flex items-center justify-center shrink-0">
            <FiUser size={14} className="text-gray-300" />
          </div>
          <div>
            <p className="text-white text-xs font-semibold">Alex Sterling</p>
            <p className="text-gray-400 text-[10px]">SuperAdmin</p>
          </div>
        </div>
      </aside>
    </>
  );
}

function Topbar({ setOpen }) {
  return (
    <div className="bg-white border-b border-gray-200 px-4 sm:px-6 flex items-center gap-3 h-14 sticky top-0 z-10">
      <button className="lg:hidden p-1.5 text-gray-500 hover:bg-gray-100 rounded-lg" onClick={() => setOpen(o => !o)}>
        <FiMenu size={20} />
      </button>
      <div className="relative flex-1 max-w-xs sm:max-w-sm">
        <FiSearch size={14} className="absolute left-3 top-3 text-gray-400" />
        <input type="text" placeholder="Search investor records..." className="w-full pl-8 pr-3 py-2 text-xs border border-gray-200 rounded-xl bg-gray-50 focus:outline-none focus:ring-1 focus:ring-emerald-600" />
      </div>
      <div className="flex items-center gap-3 ml-auto">
        <FiBell size={18} className="text-gray-500 cursor-pointer" />
        <FiHelpCircle size={18} className="text-gray-500 cursor-pointer" />
        <button className="hidden sm:flex items-center gap-1.5 text-xs font-medium text-gray-700 hover:text-gray-900">
          Admin Profile <FiChevronDown size={14} />
        </button>
      </div>
    </div>
  );
}

function StatsCard() {
  return (
    <div className="bg-emerald-800 rounded-2xl p-5 text-white">
      <div className="grid grid-cols-2 gap-4">
        {[
          { label: "TOTAL INVESTED", value: "$1,250,000", big: true },
          { label: "SHARES OWNED", value: "120", big: true },
          { label: "ACTIVE PROPERTIES", value: "05", big: true },
          { label: "ACCOUNT STATUS", value: "Active", dot: true },
        ].map(s => (
          <div key={s.label}>
            <p className="text-emerald-300 text-[10px] font-semibold uppercase tracking-wider mb-1">{s.label}</p>
            {s.dot ? (
              <div className="flex items-center gap-1.5">
                <div className="w-2 h-2 rounded-full bg-green-400"></div>
                <span className="text-xl font-bold">{s.value}</span>
              </div>
            ) : (
              <p className={`font-bold ${s.big ? "text-2xl sm:text-3xl" : "text-xl"}`}>{s.value}</p>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

function ProfileTab({ editMode }) {
  return (
    <div className="flex flex-col xl:flex-row gap-6">
      <div className="flex-1 space-y-6">
        <div className="bg-white rounded-2xl border border-gray-200 p-5">
          <div className="flex items-center gap-2 mb-5">
            <FiUser size={17} className="text-gray-600" />
            <h3 className="text-sm font-bold text-gray-900">Personal Information</h3>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {[
              { label: "FULL NAME", value: "Julianna Reed" },
              { label: "EMAIL ADDRESS", value: "julianna.reed@private.io" },
              { label: "MOBILE NUMBER", value: "+1 (555) 012-3456" },
              { label: "RESIDENTIAL ADDRESS", value: "742 Evergreen Terrace, Springfield" },
            ].map(f => (
              <div key={f.label}>
                <p className="text-[10px] text-gray-400 uppercase tracking-wider mb-1.5">{f.label}</p>
                <input defaultValue={f.value} readOnly={!editMode}
                  className={`w-full text-sm text-gray-800 border rounded-xl px-3 py-2.5 focus:outline-none transition-colors ${editMode ? "border-emerald-400 bg-white focus:ring-1 focus:ring-emerald-500" : "border-gray-200 bg-gray-50"}`} />
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-gray-200 p-5">
          <div className="flex items-center gap-2 mb-5">
            <BsBank2 size={17} className="text-gray-600" />
            <h3 className="text-sm font-bold text-gray-900">Settlement Bank Details</h3>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {[
              { label: "BANK NAME", value: "Sovereign Private Bank" },
              { label: "ACCOUNT HOLDER", value: "Julianna Reed" },
              { label: "ACCOUNT NUMBER", value: "**** **** 8921" },
              { label: "IFSC / SWIFT CODE", value: "SOV0001242" },
            ].map(f => (
              <div key={f.label}>
                <p className="text-[10px] text-gray-400 uppercase tracking-wider mb-1.5">{f.label}</p>
                <input defaultValue={f.value} readOnly={!editMode}
                  className={`w-full text-sm text-gray-800 border rounded-xl px-3 py-2.5 focus:outline-none transition-colors ${editMode ? "border-emerald-400 bg-white focus:ring-1 focus:ring-emerald-500" : "border-gray-200 bg-gray-50"}`} />
              </div>
            ))}
          </div>
        </div>

        <div className="bg-yellow-50 border border-yellow-300 rounded-2xl p-5">
          <div className="flex items-start gap-3 mb-4">
            <FiAlertTriangle size={20} className="text-yellow-500 shrink-0 mt-0.5" />
            <div>
              <h3 className="text-sm font-bold text-yellow-800">Portfolio Override Controls</h3>
              <p className="text-xs text-yellow-700 mt-1 leading-relaxed">Changes made to current property value, adjusted ROI, or rental income distribution will <strong>directly affect</strong> Julianna Reed's portfolio valuation and generated financial reports. Please proceed with extreme caution.</p>
            </div>
          </div>
          <div className="flex flex-col sm:flex-row gap-4">
            <div>
              <p className="text-[10px] text-gray-500 uppercase tracking-wider mb-1.5">ADJUSTED ROI (%)</p>
              <input defaultValue="8.4" className="w-28 text-sm border border-gray-300 rounded-xl px-3 py-2 bg-white focus:outline-none focus:ring-1 focus:ring-yellow-400" />
            </div>
            <div>
              <p className="text-[10px] text-gray-500 uppercase tracking-wider mb-1.5">RENTAL INCOME SPLIT</p>
              <input defaultValue="Manual-Override" className="w-40 text-sm border border-gray-300 rounded-xl px-3 py-2 bg-white focus:outline-none focus:ring-1 focus:ring-yellow-400" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-gray-200 p-5">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <FiRotateCcw size={17} className="text-gray-600" />
              <h3 className="text-sm font-bold text-gray-900">Recent Audit Activity</h3>
            </div>
            <button className="text-xs text-emerald-700 font-semibold hover:underline">View All logs</button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-xs min-w-[500px]">
              <thead>
                <tr className="border-b border-gray-100">
                  {["ADMIN USER", "FIELD CHANGED", "OLD VALUE", "NEW VALUE", "TIMESTAMP"].map(h => (
                    <th key={h} className="text-left text-[10px] text-gray-400 uppercase tracking-wider pb-2 pr-4 font-medium">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {AUDIT_ROWS.map((r, i) => (
                  <tr key={i} className="border-b border-gray-50 hover:bg-gray-50 transition-colors">
                    <td className="py-3 pr-4">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-full bg-gray-200 flex items-center justify-center text-[10px] font-bold text-gray-600 shrink-0">{r.initials}</div>
                        <span className="font-medium text-gray-900">{r.user}</span>
                      </div>
                    </td>
                    <td className="py-3 pr-4 text-gray-700">{r.field}</td>
                    <td className="py-3 pr-4 text-gray-400 italic">{r.old}</td>
                    <td className="py-3 pr-4">
                      <span className={r.highlight ? "text-emerald-700 font-bold" : "text-gray-800 font-medium"}>{r.newVal}</span>
                    </td>
                    <td className="py-3 text-gray-400">{r.time}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div className="w-full xl:w-64 shrink-0 space-y-4">
        <div className="bg-white rounded-2xl border border-gray-200 p-5">
          <div className="flex items-center gap-2 mb-4">
            <FiShield size={17} className="text-gray-600" />
            <h3 className="text-sm font-bold text-gray-900">Compliance & KYC</h3>
          </div>
          <div className="space-y-3 mb-4">
            {[
              { icon: <BsPersonBadge size={18} />, label: "PAN Status", date: "VERIFIED 12 OCT 2023" },
              { icon: <BsFingerprint size={18} />, label: "Aadhaar Status", date: "VERIFIED 12 OCT 2023" },
            ].map(item => (
              <div key={item.label} className="flex items-center justify-between bg-gray-50 rounded-xl p-3 border border-gray-100">
                <div className="flex items-center gap-2">
                  <span className="text-gray-500">{item.icon}</span>
                  <div>
                    <p className="text-xs font-semibold text-gray-900">{item.label}</p>
                    <p className="text-[10px] text-emerald-700 font-medium">{item.date}</p>
                  </div>
                </div>
                <MdOutlineVerified size={20} className="text-emerald-600 shrink-0" />
              </div>
            ))}
          </div>
          <button className="w-full border border-gray-200 text-gray-700 text-xs font-semibold py-2.5 rounded-xl hover:bg-gray-50 transition-colors">Re-Verify Documents</button>
        </div>

        <div className="bg-white rounded-2xl border border-gray-200 p-5">
          <div className="flex items-center gap-2 mb-3">
            <FiFileText size={17} className="text-gray-600" />
            <h3 className="text-sm font-bold text-gray-900">Internal Admin Notes</h3>
          </div>
          <textarea rows={5} placeholder="Add administrative notes about this investor..."
            className="w-full text-xs border border-gray-200 rounded-xl p-3 resize-none focus:outline-none focus:ring-1 focus:ring-emerald-500 text-gray-700 placeholder-gray-400" />
          <p className="text-[10px] text-gray-400 mt-2">Last modified by Admin: Sarah Connor on Dec 01, 2023</p>
        </div>
      </div>
    </div>
  );
}

export default function Dashboard() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [editMode, setEditMode] = useState(true);
  const [activeTab, setActiveTab] = useState("Profile");

  return (
    <div className="flex h-screen bg-gray-100 font-sans overflow-hidden">
      <Sidebar open={sidebarOpen} setOpen={setSidebarOpen} />
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <Topbar setOpen={setSidebarOpen} />
        <main className="flex-1 overflow-y-auto p-4 sm:p-6">
          <div className="max-w-6xl mx-auto">
            <div className="flex items-center gap-2 text-xs text-gray-500 mb-4">
              <a href="#" className="hover:text-gray-700">Dashboard</a>
              <span>&rsaquo;</span>
              <a href="#" className="hover:text-gray-700">Investors</a>
              <span>&rsaquo;</span>
              <span className="text-gray-900 font-medium">Julianna Reed</span>
            </div>

            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
              <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900">Investor Details</h1>
              <div className="flex items-center gap-3">
                <span className="text-xs font-semibold text-gray-600 uppercase tracking-wider">Edit Mode</span>
                <button onClick={() => setEditMode(!editMode)}
                  className={`relative w-11 h-6 rounded-full transition-colors ${editMode ? "bg-emerald-600" : "bg-gray-300"}`}>
                  <div className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow transition-all ${editMode ? "left-6" : "left-1"}`}></div>
                </button>
                <button className="text-sm text-gray-600 hover:text-gray-900 font-medium px-3 py-2 rounded-xl hover:bg-gray-100 transition-colors">Cancel</button>
                <button className="bg-gray-900 hover:bg-gray-800 text-white text-sm font-semibold px-4 py-2 rounded-xl transition-colors">Save Changes</button>
              </div>
            </div>

            <div className="flex flex-col lg:flex-row gap-5 mb-6">
              <div className="bg-white rounded-2xl border border-gray-200 p-5 flex items-start gap-4 flex-1">
                <div className="relative shrink-0">
                  <div className="w-16 h-16 rounded-2xl bg-gray-200 overflow-hidden">
                    <img src="https://i.pravatar.cc/150?img=47" alt="Julianna Reed" className="w-full h-full object-cover" />
                  </div>
                  <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-emerald-600 rounded-full flex items-center justify-center">
                    <MdOutlineVerified size={12} className="text-white" />
                  </div>
                </div>
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2 mb-1">
                    <h2 className="text-xl font-extrabold text-gray-900">Julianna Reed</h2>
                    <span className="flex items-center gap-1 text-[10px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full">
                      <div className="w-1.5 h-1.5 rounded-full bg-emerald-500"></div>
                      KYC APPROVED
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-gray-500 mb-1">
                    <FiMail size={12} />
                    <span>julianna.reed@private.io</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-gray-500">
                    <FiPhone size={12} />
                    <span>+1 (555) 012-3456</span>
                  </div>
                </div>
              </div>
              <div className="lg:w-80 xl:w-96">
                <StatsCard />
              </div>
            </div>

            <div className="border-b border-gray-200 mb-6">
              <div className="flex gap-1 overflow-x-auto scrollbar-hide">
                {TABS.map(tab => (
                  <button key={tab} onClick={() => setActiveTab(tab)}
                    className={`whitespace-nowrap px-4 py-2.5 text-sm font-medium border-b-2 transition-colors ${activeTab === tab ? "border-emerald-700 text-gray-900" : "border-transparent text-gray-500 hover:text-gray-700"}`}>
                    {tab}
                  </button>
                ))}
              </div>
            </div>

            {activeTab === "Profile" && <ProfileTab editMode={editMode} />}
            {activeTab !== "Profile" && (
              <div className="bg-white rounded-2xl border border-gray-200 p-10 text-center text-gray-400 text-sm">
                {activeTab} content coming soon.
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}