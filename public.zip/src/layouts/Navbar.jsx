import React from "react";
import { useState, useRef, useCallback } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import { LuLogOut } from "react-icons/lu";
import ProfileDropdown from "../components/ProfileDropdown";
import { CgProfile } from "react-icons/cg";

const Navbar = () => {
  // console.log("nav");
  const [open, setOpen] = useState(true)
  const isLoggedIn = !!localStorage.getItem('token');

  const navigate = useNavigate();
  
   const handleLogout = () => {
     localStorage.removeItem('token');
     navigate('/login');
     setOpen(false)
     toast.success('Logout successfully ')
   };

  return (
    <div className="z-50 shadow-2xl   ">
      <div>
        <nav className="  mx-auto  shadow-md bg-white/40  transparent  rounded-2xl   backdrop-blur-xl">
          <div className="flex items-center justify-between px-4 sm:px-6 md:px-8 lg:px-10 h-[65px] sm:h-[70px] lg:h-[75px] max-w-screen-2xl mx-auto">
            <NavLink to="/" className="flex-shrink-0 text-black duration-200">
              logo
            </NavLink>

            <div className="hidden lg:flex items-center gap-6 text-[16px] font-medium tracking-wide">
              <div className="py-1 transition hover:text-or">
              <NavLink to="/" className="flex-shrink-0 text-black duration-200">
                 Home
              </NavLink>
            </div>
              <div className="py-1 transition hover:text-or"> 
                <NavLink to='/property'> Properties</NavLink></div>
              <div className="py-1 transition hover:text-or">About</div>
              <div className="py-1 transition hover:text-or">Contact</div>
              {/* <div className="py-1 transition hover:text-or">about</div> */}

              <div className="py-1 transition px-2 rounded-lg   "></div>
            </div>

            <div className="flex items-center gap-2 sm:gap-3">

             {!isLoggedIn && <NavLink to="/signup" className="px-4 py-2 bg-[#0F766E] hover:bg-[#0F766E] text-white rounded-lg  cursor-pointer">Get Started</NavLink>}
              {!isLoggedIn && <NavLink to="/login"  className="px-4 py-2 bg-[#0F766E] hover:bg-[#0F766E] border-2 text-white  rounded-lg cursor-pointer ">Login</NavLink>}
       
              {isLoggedIn && (
                      <>
                        <CgProfile className="w-7 h-7" />
                        <ProfileDropdown handleLogout={handleLogout} />
                      </>
                    )}
            </div>
          </div>
        </nav>
      </div>
    </div>
  );
};

export default Navbar;



